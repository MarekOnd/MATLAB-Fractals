# Fractals_with_Matlab
- scripts for calculating fractals from  
  - divergence of recurrent sequences (with functions for Mandelbrot and Nova fractal)
    - note: the expression for the next term can be changed inside the function to calculate other fractals
  - convergence of Newton method used on polynomials
- made in 2023
